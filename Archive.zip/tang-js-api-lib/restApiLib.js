/* jslint node: true */
'use strict';

let fs = require('fs');
let spec = require('swagger-tools').specs.v2;
let globalVariables = {}, applicationLogs = [];

let self = module.exports = {

    validateResponseWithSwaggerSpecDefinition: function (definitionName, swaggerSpecFile, response, callback) {

        const swaggerSpecString = fs.readFileSync(swaggerSpecFile, 'utf8');
        const swaggerObject = JSON.parse(swaggerSpecString);
        let responseBody;
        if (typeof response.body === 'string') {
            responseBody = JSON.parse(response.body);
        } else {
            responseBody = response.body;
        }

        spec.validateModel(swaggerObject, '#/definitions/' + definitionName, responseBody, function (err, result) {
            if (err) {
                callback(self.getAssertionResult(false, null, err));
            } else if (result && result.errors) {
                callback(self.getAssertionResult(false, null, result.errors));
            } else {
                callback(self.getAssertionResult(true, null, null));
            }
        });
    },

    getAssertionResult: function (success, expected, actual) {
        return {
            success: success,
            expected: expected,
            actual: actual
        };
    },

    base64Encode: function (str) {
        return new Buffer(str).toString('base64');
    },

    setGlobalVariable: function (name, value) {
        globalVariables[name] = value;
    },

    getGlobalVariable: function (name) {
        return globalVariables[name];
    },

    setApplicationLogs: function (type, value) {
        let logObject = {};
        logObject[type] = value;
        applicationLogs.push(logObject);
    },

    getApplicationLogs: function () {
        return applicationLogs;
    },

    cleanApplicationLogs: function () {
        applicationLogs = [];
    }
};