#!/usr/bin/env bash

source "${WORKSPACE}/pipelines/scripts/functions"

set -ex


echo Nothing to destroy
