###Helper shell scripts.......

Suggest `source pipelines/scripts/functions`  in all your other helper scripts to maintain a consistent operational environment

baseline should be available in `.bashrc`. Specific codebase overrides place in funtions

#### Note: Ensure all scripts are executable
