/*
 * Author: Abhay Chrungoo <abhay@ziraffe.io>
 * Contributing HOWTO: TODO
 */
def deploy(String targetBranch, context){
}
def purge(String targetBranch, context) {
}

def name(){
	return "bluemix"
}

return this;
