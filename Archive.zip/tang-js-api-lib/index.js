
module.exports = {
  restApiLib: require('./restApiLib'),
  soapApiLib: require('./soapApiLib')

};
