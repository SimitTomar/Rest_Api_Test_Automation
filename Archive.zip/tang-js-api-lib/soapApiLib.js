const soap = require('soap');
const await = require('asyncawait/await');
let globalClient, soapResponse;
let self = module.exports = {
    //this function fetches the response from a soap API by providing the wsdl, method, endpoint and Request Arguments
    getSoapResponse: function (options) {
        let endpointOptions = {
            endpoint: options.uri
        };
        await (function createSoapClient(callback) {
            soap.createClient(options.wsdl, endpointOptions, function (err, client) {
                if (err) {
                    console.log('Unable to create soap client', err);
                    callback();
                }
                client.addSoapHeader(options.headers);
                globalClient = client;
                eval('client.' + options.method)(options.qs, function (err, result) {
                    if (result) {
                        soapResponse = result;
                        callback();
                    } else {
                        console.log('Error in Soap request', err.body);
                        callback();
                    }
                });
            });
        });
        return soapResponse;
    },
    getlastRequest: function () {
        console.log(globalClient.lastRequest);
    },
    setSecurity: function (username, password) {
        console.log(globalClient.setSecurity(new soap.BasicAuthSecurity(username, password)));
    }
};