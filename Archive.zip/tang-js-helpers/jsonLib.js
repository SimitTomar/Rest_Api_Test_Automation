var yaml = require("js-yaml");
var fs = require("fs");
var path = require("path");
var deepEqual = require('deep-equal');
var _ = require("underscore");
var alasql = require("alasql");
var moment = require('moment');
var JSONPath = require('advanced-json-path');
var cloneDeep = require("lodash.clonedeep"),
    _maxDepth;
var fileLocation;

var self = module.exports = {

    //This function compares two JSON Objects
    compare: function (lhs,lhsName,rhs,rhsName) {
        var printMessage;

        //Convert the JSONs into array incase they contain only single record
        if (!(lhs instanceof Array))
            lhs = [lhs];

        if (!(rhs instanceof Array))
            rhs = [rhs];

        //Match the number of records between JSONs
        var recordsMatch = (lhs.length == rhs.length);

        //Default value of overall result is set to be the same as the match result
        var overallResult = recordsMatch;
        if(overallResult == false)
            printMessage = 'Count of records did not match. '+lhsName+': '+lhs.length+', '+rhsName+': '+rhs.length;

        //Loop through the expected records (LHS)
        var rhsUnmatched = rhs;
        var lhsUnmatched = lhs;
        for (var i = 0; i < lhs.length; i++) {
            var rowResult = false;
            //Loop through the actual records (RHS) any try matching the selected LHS record with each of the RHS records
            for (var j = 0; j < rhs.length; j++) {
                rowResult = rowResult || deepEqual(lhs[i], rhs[j]);

                //In case a match is found, remove that record and store the remaining in another object.
                //At the end, these two objects will hold the records which did not find any match
                if (rowResult) {
                    rhsUnmatched = rhsUnmatched.filter(function(x){return x !== rhs[j]; });
                    lhsUnmatched = lhsUnmatched.filter(function(x){return x !== lhs[i]; });
                    //Break the loop in case a match is found
                    break;
                }
            }

            //Determine the ovarall result on the basis of individual record results
            overallResult = overallResult && rowResult
        }

        if (overallResult == false) {
            printMessage = printMessage + '\nList of ' + rhsName + ' records not matching with ' + lhsName + '\n';

            if (rhsUnmatched.length == 0)
                printMessage = printMessage + 'NONE\n';
            else
                printMessage = printMessage + JSON.stringify(rhsUnmatched) + '\n';

            printMessage = printMessage + 'List of ' + lhsName + ' records not matching with ' + rhsName + '\n';
            if (lhsUnmatched.length == 0)
                printMessage = printMessage + 'NONE\n';
            else
                printMessage = printMessage + JSON.stringify(lhsUnmatched) + '\n';
        }

        return [overallResult,printMessage];
    },

    //This function filters the JSON fields and merges them into a single json object
    getFilteredJsonFields: function (jsonData,keyNames) {

        //read the keys to be filtered from the JSON object
        //var keys = keyNames.split(',');
        var keys = keyNames;

        //if JSON data is an array then loop through the records and repeat for all of them
        if (jsonData instanceof Array) {
            var finalJSON = [];
            for (var i = 0; i < jsonData.length; i++) {

                //JSON to store keys per object
                var perRecordJSON = new Object();

                //loop through the keys to read their value and store in a new object
                for (var j = 0; j < keys.length; j++) {

                    //Remove leading or trailing spaces
                    keys[j] = keys[j].trim();

                    //Create an entry in the resultant JSON for the key, if it is found
                    perRecordJSON[keys[j]] = JSONPath(JSON.parse(JSON.stringify(jsonData[i])), '$..' + keys[j]);
                }
                //Push the record formed in the above loop into the resultant JSON array as one object
                finalJSON.push(perRecordJSON);
            }

            return finalJSON;
        }

        //if JSON data is not an array then filter the keys to the new object for the only record
        else
        {
            var perRecordJSON = {};

            for (var j = 0; j < keys.length; j++) {

                //Remove leading or trailing spaces
                keys[j] = keys[j].trim();
                //Create an entry in the resultant JSON for the key, if it is found
                perRecordJSON[keys[j]] = JSONPath(JSON.parse(JSON.stringify(jsonData)), '$..' + keys[j]);
            }

            return perRecordJSON;
        }
    },

    //This function replaces the specified keys to a new name as specified in the mapping sheet which should be placed
    //under 'columnMappingFolderPath'
    replaceKeys: function (JsonData,keyNames,columnMappingFolderPath) {
        function escape(text) {
            return text.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, "\\$&");
        }

        /**
         * Traverses an object recursively and substitutes the specified keys for the given values
         *
         * @param {Object} obj The object in which we want to change the keys
         * @param {Object} keysToChange an object of the form {oldKey1: "newKey1", oldKey2: "newKey2"}
         */
        var _recursiveChangeKeys = function(obj, keysToChange, depth){
            if(depth === _maxDepth){
                return;
            }
            if(obj instanceof Object){
                for(var oldkey in obj){
                    if(obj.hasOwnProperty(oldkey)){
                        for(var keyToChange in keysToChange){

                            // If the key in keysToChange is a replacement
                            if(keysToChange[keyToChange].replace){

                                var keyToChangeRe = new RegExp(escape(keyToChange), 'g');

                                // We replace the matched characters in the old key with the given string
                                var newkey = oldkey.replace(keyToChangeRe, keysToChange[keyToChange].value);
                                if(newkey !== oldkey){
                                    obj[newkey] = obj[oldkey];
                                    delete obj[oldkey];
                                }
                            }
                            // Else if its just a string
                            else {
                                if(oldkey === keyToChange &&
                                    // Lets assure we dont overwrite anything
                                    !obj.hasOwnProperty(keysToChange[keyToChange].value)){

                                    obj[keysToChange[keyToChange].value] = obj[oldkey];
                                    delete obj[oldkey];
                                }
                            }
                        }
                        _recursiveChangeKeys(obj[oldkey], keysToChange, ++depth);
                    }
                }
            }
        };
        var recursiveChangeKeys = function(obj, keysToChange, maxDepth){
            _maxDepth = maxDepth;
            var newobj = cloneDeep(obj);
            _recursiveChangeKeys(newobj, keysToChange, 0);
            return newobj;
        };

        var changeKeys = new Object();

        //Read all the key mappings from the mapping file
        var mappings = yaml.load(fs.readFileSync(columnMappingFolderPath));

        //Read the keyNames received as parameter into an array
        //var keysToReplace = keyNames.split(',');
        var keysToReplace = keyNames;

        for(var i=0;i<keysToReplace.length;i++) {
            var keyFound = false;
            for (var key in mappings) {
                //search for the key to be replaced in the mapping file
                if (keysToReplace[i].trim()==key) {
                    //if found, add it to the object which will contains the list of key mappings. Repeat for all the sent keys
                    changeKeys[mappings[key]] = {value: key};
                    keyFound = true;
                    break;
                }
            }
        }
        return recursiveChangeKeys(JsonData, changeKeys);
    },

    queryJsonRecords: function (query, jsonData) {
        //var result = alasql('SELECT ' + param + ', COUNT(*) AS cnt FROM ? GROUP BY ' + param, [jsonData]);
        if (!(jsonData instanceof Array))
            jsonData =  [jsonData];

        var result = alasql(query, [jsonData]);
        return result;

    },

    //This function takes a key and returns its value from 'data' in an array
    getValueOfKey: function(data,key){

        //Extract 'value' corresponding to the key
        var keyValue = JSONPath(JSON.parse(JSON.stringify(data)), '$..' + key);
        if(keyValue==false)
            return [];
        else if (!(keyValue instanceof Array)){
            keyValue = [keyValue];
            return keyValue;
        }
        else
            return keyValue;
    },

    //This is specific to AISP track for retrieving cassandra data
    getValueOfKeyForQuery: function(data,primaryKey,type){

        //Extract 'value' corresponding to the primary key
        var primaryKeyValue = JSONPath(JSON.parse(JSON.stringify(data)), '$..' + primaryKey);

        if(primaryKeyValue=='false')
            return '';
        else {
            if (!(primaryKeyValue instanceof Array))
                primaryKeyValue = [primaryKeyValue];

            if (type !== 'int') {
                for (var a = 0; a < primaryKeyValue.length; a++) {
                    primaryKeyValue[a] = "'" + primaryKeyValue[a] + "'";
                }
            }

            return primaryKeyValue;
        }
    },

    //This function returns location of the file 'filename' which is placed at any location
    //under the directory 'currentDirPath'
    searchFilePath: function (currentDirPath,filename,callback) {
        fs.readdirSync(currentDirPath).forEach(function (name) {
            var filePath = path.join(currentDirPath, name);
            var stat = fs.statSync(filePath);
            if (stat.isFile() && (name==filename+'.json'||name==filename+'.txt')) {
                callback(filePath);
            } else if (stat.isDirectory()) {
                self.searchFilePath(filePath, filename,callback);
            }
        });
    },

    //This function reads the 'filename' located anywhere under the directory 'directory' and returns a JSON Object
    readFileData: function(directory,filename){
        self.searchFilePath(directory, filename,function(filePath) {
            fileLocation = filePath;
        });
        return JSON.parse(fs.readFileSync(fileLocation).toString());
        //return fs.readFileSync(fileLocation).toString();
    },

    //This function writes into the 'filename' located anywhere under the directory 'directory'
    writeIntoFile: function(directory,filename,data){
        self.searchFilePath(directory, filename,function(filePath) {
            fileLocation = filePath;
        });
        fs.writeFileSync(fileLocation, JSON.stringify(data),'utf-8');
    },

    //This function accepts a 2D array containing key-value pair and changes each of the key's value
    // in the JSON object 'data' to its corresponding 'value'
    //The input JSON object should be a simple JSON with no nested structure
    changeMultipleKeyValues: function(data,fields){
        var fieldsTemp = fields.raw();
        var keys=[];
        var values=[];
        for(var i=1;i<fieldsTemp.length;i++){
            keys[i] = fieldsTemp[i][0];
            values[i] = fieldsTemp[i][1];

            values[i] = values[i]=='null' ? null:values[i].trim();
            if (data instanceof Array)
                data[0][keys[i]] = values[i];
            else
                data[keys[i]] = values[i];
        }
        return data;
    },

    //This function takes multiple childKey (under 'parentKey'):value pair in 'updateFields' and changes the value in the JSON object 'data'
    changeMultipleChildKeyValues: function(data,parentKey,updateFields,index){
        var fields = Object.keys(updateFields);
        for(var i=0; i < fields.length;i++){
            data = self.changeChildKeyValue(data, parentKey,fields[i], index,updateFields[fields[i]]);
        }

        return data;
    },

    //This function changes the value of the 'key' in the JSON object 'data' to 'value'.
    //'key' - 'value' pair is added to the JSON if it doesn't exist
    //The input JSON object should be a simple JSON with no nested structure
    changeKeyValue: function(data,key,value){
        value = value=='null' ? null:value;
        if (data instanceof Array)
            data[0][key] = value;
        else
            data[key] = value;

        return data;
    },

    //This function changes the value of the 'childKey' of the given 'index' under 'parentKey' in the JSON object 'data' to 'value'.
    changeChildKeyValue: function(data,parentKey,childKey,index,value){
        value = value=='null' ? null:value;
        if (data instanceof Array)
            data[0][parentKey][index][childKey] = value;
        else
            data[parentKey][index][childKey] = value;

        return data;
    },

    //This function removes the key from the JSON object 'data' and returns the resultant JSON object
    removeKey: function(data,key){
        if (data instanceof Array) {
            for(var i=0; i<data.length;i++)
                delete data[i][key];
        }
        else
            delete data[key];

        return data;
    },

    //This function removes the 'childKey' of the given 'index' under 'parentKey' from the JSON object 'data' and returns the resultant JSON object
    removeChildKey: function(data,parentKey,childKey,index){
        if (data instanceof Array) {
            for(var i=0; i<data.length;i++)
                delete data[i][parentKey][index][childKey];
        }
        else
            delete data[parentKey][index][childKey];

        return data;
    },

    //This function returns the count of number of records present in the JSON object 'data'
    countRecords: function(data){
        if (data instanceof Array) {
            return data.length;
        }
        else
            return 1;
    },

    //This function filters out those records from JSON object 'data' where the value of 'key' matches with 'value'
    filterRecords: function (data,key,value) {
        var result =[];
        if(data instanceof Array){

            //Loop through the data's records
            for(var i=0;i<data.length;i++){

                //Push the record into the result if the key's value matches with 'value'
                if(data[i][key]==value)
                    result.push(data[i]);
            }
        }
        else {
            if(data.key==value)
                result.push(data);
        }
        return result;

    },

    //This function filters out those records from JSON object 'data' where the value of 'key' does not matche with 'value'
    filterOutRecords: function (data,key,value) {
        var result =[];
        if(data instanceof Array){

            //Loop through the data's records
            for(var i=0;i<data.length;i++){

                //Push the record into the result if the key's value matches with 'value'
                if(data[i][key]!=value)
                    result.push(data[i]);
            }
        }
        else {
            if(data.key!=value)
                result.push(data);
        }
        return result;

    },

    //This function takes keys as array and returns its value from 'data' in an array
    getValueOfKeys: function(data,keys){

        var keyValues=[];
        for (var i = 0; i < keys.length; i++) {
            keyValues.push(self.getValueOfKey(data, keys[i]));
        }
        return keyValues;

    },

    //this function flattens a json (data) where the value of 'key' is an array of object
    flattenJson: function(data,key){
        var keyValue = data[key];
        if(keyValue==null)
            return data;
        else if(keyValue.length==0)
            return data;
        else {
            var common = _.omit(data, key);

            var result = [];
            for (var i = 0; i < keyValue.length; i++)
                result.push(_.extend(keyValue[i], common));

            return result;
        }
    },

    //This function merges two json source1 and source2 based on the value of keys passed in 'keys' array
    mergeJson: function(source1,source2,keys){

        //Convert the JSONs into array incase they contain only single record
        if (!(source1 instanceof Array))
            source1 = [source1];

        if (!(source2 instanceof Array))
            source2 = [source2];

        var query = 'SELECT * FROM ? source1 JOIN ? source2 ON ';

        //Loop through the joiner columns of the last two query executions
        for(var j=0;j<keys.length;j++){

            // Keep adding them to the join query
            query = query +'source1.' + keys[j] + ' = source2.' + keys[j];

            //Append 'AND' till the second last pass
            if(j!=keys.length-1)
                query = query +' AND ';
        }

        return alasql(query,[source1,source2]);
    },

    //This function converts the value of fields to int. data = json data, fields = array of fields
    convertValuesToInt: function(data, fields){
        if(data instanceof Array) {
            for (var i=0;i<data.length;i++){
                for (var j=0;j<fields.length;j++){
                    data[i][fields[j]] = parseInt(data[i][fields[j]]);
                }
            }
        }

        else{
            for (j=0;j<fields.length;j++){
                data[fields[j]] = parseInt(data[fields[j]]);
            }
        }
        return data;
    },

    //This function flattens a json which has some keys whose value is an object
    //data = json data, key = array of keys whose value is a object
    flattenJsonHavingObjectKeys: function(data,key){
        var common = data;
        for(var i=0;i<key.length;i++)
            common = _.omit(common, key[i]);

        for(i=0;i<key.length;i++){
            var keyValue = data[key[i]];
            if(keyValue!=null||keyValue.length!=0)
                common = _.extend(keyValue, common);
        }
        return common;
    },

    //This function filters out those records from JSON object 'data' where the value of 'key' is less than 'value'
    filterRecordsOnDate: function (data,key,value) {
        var result =[];
        if(data instanceof Array){

            //Loop through the data's records
            for(var i=0;i<data.length;i++){

                var diff = (moment(data[i][key].toString())).diff(moment(value), 'days');
                //Push the record into the result if the key's value is greater than zero
                if(diff > 0)
                    result.push(data[i]);
            }
        }
        else {
            if(data.key > value)
                result.push(data);
        }
        return result;

    },

    //sort Json (data) on two fields key1 and key2 by specifying their respective sort order (A for Ascending and D for Descending)
    sortJsonOnTwoFields: function (data,key1,key1SortOrder,key2,key2SortOrder) {
        cmp = function(x, y){
            return x > y ? 1 : x < y ? -1 : 0;
        };

        switch(key1SortOrder +'|'+ key2SortOrder){
            case 'A|A':
                return data.sort(function(a, b){
                    return cmp([cmp(a[key1], b[key1]), cmp(a[key2], b[key2])],[cmp(b[key1], a[key1]), cmp(b[key2], a[key2])]);
                });
                break;
            case 'A|D':
                return data.sort(function(a, b){
                    return cmp([cmp(a[key1], b[key1]), -cmp(a[key2], b[key2])],[cmp(b[key1], a[key1]), -cmp(b[key2], a[key2])]);
                });
                break;
            case 'D|A':
                return data.sort(function(a, b){
                    return cmp([-cmp(a[key1], b[key1]), cmp(a[key2], b[key2])],[-cmp(b[key1], a[key1]), cmp(b[key2], a[key2])]);
                });
                break;
            case 'D|D':
                return data.sort(function(a, b){
                    return cmp([-cmp(a[key1], b[key1]), -cmp(a[key2], b[key2])],[-cmp(b[key1], a[key1]), -cmp(b[key2], a[key2])]);
                });
                break;
        }
    },

    // sort Json (data) on one field key and specifying its respective sort order (A for Ascending and D for Descending)
    sortJsonOnOneField: function (data,key,keySortOrder){
        if(keySortOrder == 'A') {
            return data.sort(function (a, b) {
                return a['sequence_number'] - b['sequence_number'];
            });
        }
        else if(keySortOrder == 'D') {
            return data.sort(function (a, b) {
                return b['sequence_number'] - a['sequence_number'];
            });

        }
    }
};