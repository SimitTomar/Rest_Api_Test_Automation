var mockserver = require('mockserver-grunt');

mockserver.start_mockserver({
    serverPort: 10080,
    verbose: true
});
